#import <UIKit/UIKit.h>

//! Project version number for TTTPlayerKit.
FOUNDATION_EXPORT double TTTPlayerKitVersionNumber;

//! Project version string for TTTPlayerKit.
FOUNDATION_EXPORT const unsigned char TTTPlayerKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TTTPlayerKit/PublicHeader.h>
#import "TTTPlayer.h"
